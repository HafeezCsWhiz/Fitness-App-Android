# StepCounterKotlinAndroidApp 

. Step counter using background service and upadte main UI and Notification progress with steps, calories burnt and distance covered.<br />


# Required
.  Android Studio 4.0 or newer required.<br />
.  Physical device required<br />


